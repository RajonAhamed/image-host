// Quantum Lovable — PIX checkout (Brazil) for the Chrome extension.
// Anonymous flow: calls ext-pix-create / ext-pix-status edge functions and
// activates the issued license straight into chrome.storage.local.
(function(){
  "use strict";
  if (window.__qlPixLoaded) return;
  window.__qlPixLoaded = true;

  var SUPABASE_URL = "https://itsgcyiyemstpfafxrpq.supabase.co";
  var ANON_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml0c2djeWl5ZW1zdHBmYWZ4cnBxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEwMTgxMjEsImV4cCI6MjA5NjU5NDEyMX0.-MIslf_PAA9VCmKNCGJ_9QTXze4ej7OQEZ1UYKC3UgE";

  var PIX_PLANS = [
    { slug: "semanal",   name: "Semanal",   price: "49,90",  period: "/sem", icon: "⚡", badge: "7d" },
    { slug: "mensal",    name: "Mensal",    price: "97,90",  period: "/mês", icon: "👑", badge: "30d", popular: true },
    { slug: "vitalicio", name: "Vitalício", price: "149,90", period: "único", icon: "♾️", badge: "∞" },
  ];

  function t(s){
    try { return (window.QL_I18N && window.QL_I18N.t) ? window.QL_I18N.t(s) : s; }
    catch(e){ return s; }
  }
  function esc(s){
    return String(s == null ? "" : s)
      .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
      .replace(/"/g,"&quot;").replace(/'/g,"&#39;");
  }
  function el(html){
    var d = document.createElement("div");
    d.innerHTML = html;
    return d.firstElementChild;
  }

  // CSS injected once
  function ensureCss(){
    if (document.getElementById("ql-pix-css")) return;
    var s = document.createElement("style");
    s.id = "ql-pix-css";
    s.textContent = [
      "#ql-floating .ql-pix-wrap{padding:14px;display:flex;flex-direction:column;gap:12px}",
      "#ql-floating .ql-pix-title{font-size:14px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px;margin:0}",
      "#ql-floating .ql-pix-sub{font-size:11px;color:rgba(255,255,255,0.65);margin:-6px 0 6px}",
      "#ql-floating .ql-pix-plans{display:flex;gap:8px}",
      "#ql-floating .ql-pix-plan{flex:1;border:1px solid rgba(255,255,255,0.1);background:rgba(255,255,255,0.03);border-radius:10px;padding:10px 8px;text-align:center;cursor:pointer;transition:all .2s;position:relative}",
      "#ql-floating .ql-pix-plan:hover{border-color:#10b981;background:rgba(16,185,129,0.08)}",
      "#ql-floating .ql-pix-plan.active{border-color:#10b981;background:rgba(16,185,129,0.12);box-shadow:0 0 0 1px #10b981 inset}",
      "#ql-floating .ql-pix-plan .pp-name{font-size:11px;color:rgba(255,255,255,0.8);font-weight:600}",
      "#ql-floating .ql-pix-plan .pp-price{font-size:14px;color:#fff;font-weight:800;margin-top:4px}",
      "#ql-floating .ql-pix-plan .pp-period{font-size:10px;color:rgba(255,255,255,0.5)}",
      "#ql-floating .ql-pix-plan .pp-pop{position:absolute;top:-7px;left:50%;transform:translateX(-50%);background:#10b981;color:#000;font-size:9px;font-weight:800;padding:2px 6px;border-radius:6px}",
      "#ql-floating .ql-pix-field{display:flex;flex-direction:column;gap:4px}",
      "#ql-floating .ql-pix-field label{font-size:10px;color:rgba(255,255,255,0.6);font-weight:600;letter-spacing:.05em;text-transform:uppercase}",
      "#ql-floating .ql-pix-field input{background:rgba(0,0,0,0.3);border:1px solid rgba(255,255,255,0.1);border-radius:8px;padding:8px 10px;color:#fff;font-size:12px;outline:none;transition:border-color .15s}",
      "#ql-floating .ql-pix-field input:focus{border-color:#10b981}",
      "#ql-floating .ql-pix-submit{background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:0;border-radius:10px;padding:11px;font-weight:700;cursor:pointer;font-size:13px;display:flex;align-items:center;justify-content:center;gap:8px;transition:transform .15s}",
      "#ql-floating .ql-pix-submit:hover:not(:disabled){transform:translateY(-1px)}",
      "#ql-floating .ql-pix-submit:disabled{opacity:0.6;cursor:not-allowed}",
      "#ql-floating .ql-pix-err{background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);color:#fca5a5;border-radius:8px;padding:8px 10px;font-size:11px}",
      "#ql-floating .ql-pix-back{background:transparent;border:1px solid rgba(255,255,255,0.1);color:rgba(255,255,255,0.7);border-radius:8px;padding:7px 10px;font-size:11px;cursor:pointer;align-self:flex-start}",
      "#ql-floating .ql-pix-qr{display:flex;flex-direction:column;align-items:center;gap:10px;padding:8px;background:#fff;border-radius:10px;margin:0 auto;max-width:200px}",
      "#ql-floating .ql-pix-qr img{display:block;width:180px;height:180px}",
      "#ql-floating .ql-pix-code{background:rgba(0,0,0,0.4);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:8px;font-family:monospace;font-size:10px;color:rgba(255,255,255,0.75);word-break:break-all;max-height:60px;overflow:auto}",
      "#ql-floating .ql-pix-copy{background:rgba(16,185,129,0.15);color:#34d399;border:1px solid rgba(16,185,129,0.3);border-radius:8px;padding:8px;font-weight:700;cursor:pointer;font-size:12px}",
      "#ql-floating .ql-pix-status{text-align:center;font-size:12px;color:rgba(255,255,255,0.7);display:flex;align-items:center;justify-content:center;gap:6px;padding:8px}",
      "#ql-floating .ql-pix-spin{width:12px;height:12px;border:2px solid rgba(16,185,129,0.3);border-top-color:#10b981;border-radius:50%;animation:qlpix-spin .8s linear infinite;display:inline-block}",
      "@keyframes qlpix-spin{to{transform:rotate(360deg)}}",
      "#ql-floating .ql-pix-success{text-align:center;padding:14px}",
      "#ql-floating .ql-pix-success .ps-emoji{font-size:36px;margin-bottom:6px}",
      "#ql-floating .ql-pix-success .ps-key{background:rgba(16,185,129,0.1);border:1px dashed rgba(16,185,129,0.4);border-radius:8px;padding:10px;font-family:monospace;font-size:12px;color:#34d399;margin:10px 0;word-break:break-all}",
    ].join("\n");
    document.head.appendChild(s);
  }

  function bodyEl(){ return document.getElementById("ql-body"); }

  function renderForm(preselect){
    ensureCss();
    var body = bodyEl();
    if (!body) return;
    var selected = preselect || "mensal";
    body.innerHTML = '<div class="ql-pix-wrap">' +
      '<button class="ql-pix-back" id="qlpix-back">← ' + esc(t("Voltar")) + '</button>' +
      '<h3 class="ql-pix-title">🇧🇷 ' + esc(t("PIX (Brasil)")) + '</h3>' +
      '<p class="ql-pix-sub">' + esc(t("Escolha o método de pagamento")) + '</p>' +
      '<div class="ql-pix-plans" id="qlpix-plans">' +
        PIX_PLANS.map(function(p){
          return '<div class="ql-pix-plan' + (p.slug === selected ? ' active' : '') + '" data-slug="' + p.slug + '">' +
            (p.popular ? '<span class="pp-pop">★</span>' : '') +
            '<div class="pp-name">' + esc(p.icon) + ' ' + esc(p.name) + '</div>' +
            '<div class="pp-price">R$ ' + esc(p.price) + '</div>' +
            '<div class="pp-period">' + esc(p.period) + '</div>' +
          '</div>';
        }).join('') +
      '</div>' +
      '<div class="ql-pix-field"><label>' + esc(t("Nome completo")) + '</label><input id="qlpix-name" placeholder="' + esc(t("Nome e sobrenome (ex: João Silva)")) + '" autocomplete="name"></div>' +
      '<div class="ql-pix-field"><label>Email</label><input id="qlpix-email" type="email" placeholder="seu@email.com" autocomplete="email"></div>' +
      '<div class="ql-pix-field"><label>CPF</label><input id="qlpix-cpf" placeholder="' + esc(t("CPF (apenas números)")) + '" inputmode="numeric" maxlength="14"></div>' +
      '<div class="ql-pix-field"><label>' + esc(t("Telefone com DDD")) + '</label><input id="qlpix-phone" placeholder="11999998888" inputmode="numeric" maxlength="15"></div>' +
      '<div id="qlpix-err" style="display:none"></div>' +
      '<button class="ql-pix-submit" id="qlpix-submit">⚡ ' + esc(t("Gerar PIX")) + '</button>' +
    '</div>';

    body.querySelector("#qlpix-back").addEventListener("click", goBackToCheckout);
    body.querySelectorAll(".ql-pix-plan").forEach(function(el){
      el.addEventListener("click", function(){
        body.querySelectorAll(".ql-pix-plan").forEach(function(x){ x.classList.remove("active"); });
        el.classList.add("active");
      });
    });
    body.querySelector("#qlpix-submit").addEventListener("click", submitForm);
  }

  function goBackToCheckout(){
    // Simplest: reload the payment screen via the existing global handler if present
    try {
      var box = document.getElementById("ql-floating");
      if (window.showPaymentUI && box) { window.showPaymentUI(box); return; }
    } catch(e){}
    // Fallback: reload
    location.reload();
  }

  function showError(msg){
    var e = document.getElementById("qlpix-err");
    if (!e) return;
    e.className = "ql-pix-err";
    e.style.display = "block";
    e.textContent = "✗ " + msg;
  }

  function getActiveSlug(){
    var a = document.querySelector("#qlpix-plans .ql-pix-plan.active");
    return a ? a.getAttribute("data-slug") : "mensal";
  }

  function submitForm(){
    var name = (document.getElementById("qlpix-name") || {}).value || "";
    var email = (document.getElementById("qlpix-email") || {}).value || "";
    var cpf = ((document.getElementById("qlpix-cpf") || {}).value || "").replace(/\D/g,"");
    var phone = ((document.getElementById("qlpix-phone") || {}).value || "").replace(/\D/g,"");
    var slug = getActiveSlug();

    var nameParts = name.trim().split(/\s+/).filter(function(p){ return p.length >= 2; });
    if (nameParts.length < 2) return showError(t("Nome e sobrenome (ex: João Silva)"));
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return showError("Email inválido.");
    if (cpf.length !== 11) return showError("CPF deve ter 11 dígitos.");
    if (phone.length < 10 || phone.length > 11) return showError(t("Telefone com DDD"));

    var btn = document.getElementById("qlpix-submit");
    if (btn){ btn.disabled = true; btn.textContent = "⏳ " + t("Processando..."); }
    var errEl = document.getElementById("qlpix-err"); if (errEl) errEl.style.display = "none";

    fetch(SUPABASE_URL + "/functions/v1/ext-pix-create", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "apikey": ANON_KEY,
        "Authorization": "Bearer " + ANON_KEY,
      },
      body: JSON.stringify({
        plan_slug: slug,
        customer: { name: name.trim(), email: email.trim(), cpf: cpf, phone: phone },
      }),
    }).then(function(r){ return r.json(); }).then(function(j){
      if (!j || !j.success) {
        if (btn){ btn.disabled = false; btn.textContent = "⚡ " + t("Gerar PIX"); }
        return showError(j && j.error ? j.error : t("Pagamento falhou. Tente novamente."));
      }
      renderWaiting(j);
    }).catch(function(){
      if (btn){ btn.disabled = false; btn.textContent = "⚡ " + t("Gerar PIX"); }
      showError(t("Erro de conexão."));
    });
  }

  function renderWaiting(tx){
    var body = bodyEl();
    if (!body) return;
    var qr = "https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=" + encodeURIComponent(tx.pix_code || "");
    body.innerHTML = '<div class="ql-pix-wrap">' +
      '<h3 class="ql-pix-title">🇧🇷 ' + esc(tx.plan_name) + ' — R$ ' + esc(tx.amount) + '</h3>' +
      '<div class="ql-pix-qr"><img src="' + qr + '" alt="QR Code PIX"></div>' +
      '<button class="ql-pix-copy" id="qlpix-copy">📋 ' + esc(t("Copiar código PIX")) + '</button>' +
      '<div class="ql-pix-code">' + esc(tx.pix_code || "") + '</div>' +
      '<div class="ql-pix-status" id="qlpix-status"><span class="ql-pix-spin"></span> ' + esc(t("Aguardando pagamento...")) + '</div>' +
    '</div>';

    var copy = document.getElementById("qlpix-copy");
    if (copy){
      copy.addEventListener("click", function(){
        try {
          navigator.clipboard.writeText(tx.pix_code || "");
          copy.textContent = "✅ " + t("Código copiado!");
          setTimeout(function(){ copy.textContent = "📋 " + t("Copiar código PIX"); }, 2000);
        } catch(e){}
      });
    }

    pollStatus(tx.identifier);
  }

  function pollStatus(identifier){
    var attempts = 0;
    var maxAttempts = 180; // ~12 min @ 4s
    var timer = setInterval(function(){
      attempts++;
      if (attempts > maxAttempts) { clearInterval(timer); return; }
      fetch(SUPABASE_URL + "/functions/v1/ext-pix-status?identifier=" + encodeURIComponent(identifier), {
        headers: { "apikey": ANON_KEY, "Authorization": "Bearer " + ANON_KEY },
      }).then(function(r){ return r.json(); }).then(function(j){
        if (!j) return;
        if (j.license_key && (j.status === "paid" || j.status === "completed" || j.status === "approved" || j.status === "success")) {
          clearInterval(timer);
          renderSuccess(j);
        }
      }).catch(function(){});
    }, 4000);
  }

  function renderSuccess(tx){
    var body = bodyEl();
    if (!body) return;
    body.innerHTML = '<div class="ql-pix-success">' +
      '<div class="ps-emoji">🎉</div>' +
      '<h3 class="ql-pix-title" style="justify-content:center">' + esc(t("Pagamento confirmado!")) + '</h3>' +
      '<p class="ql-pix-sub">' + esc(t("Sua chave de licença")) + '</p>' +
      '<div class="ps-key" id="qlpix-key">' + esc(tx.license_key) + '</div>' +
      '<button class="ql-pix-copy" id="qlpix-key-copy" style="margin-bottom:8px">📋 ' + esc(t("📋 Copiar Chave")) + '</button>' +
      '<button class="ql-pix-submit" id="qlpix-activate">🔑 ' + esc(t("🔑 Ativar Agora")) + '</button>' +
    '</div>';

    var copy = document.getElementById("qlpix-key-copy");
    if (copy) copy.addEventListener("click", function(){
      try { navigator.clipboard.writeText(tx.license_key); copy.textContent = "✅ " + t("✅ Copiado!"); } catch(e){}
    });
    var act = document.getElementById("qlpix-activate");
    if (act) act.addEventListener("click", function(){
      var expiresAt = null;
      if (!tx.is_lifetime && tx.paid_at) {
        // optimistic: license_key validation will confirm exact expiry
        expiresAt = null;
      }
      try {
        chrome.storage.local.set({
          ql_license_valid: true,
          ql_license_key: tx.license_key,
          ql_expires_at: expiresAt,
          ql_license_status: "active",
          ql_session_id: null,
        }, function(){
          location.reload();
        });
      } catch(e){ location.reload(); }
    });
  }

  // --- Inject "PIX (Brasil)" button into the existing checkout screen ---
  function tryInjectPixButton(){
    var box = document.getElementById("ql-floating");
    if (!box) return;
    var methodsRow = box.querySelector(".ql-checkout-methods, .ql-method-row");
    var anyMethod = box.querySelector(".ql-method-btn");
    if (!anyMethod) return;
    var parent = (methodsRow || anyMethod.parentElement);
    if (!parent) return;
    if (parent.querySelector(".ql-method-btn[data-method=pix]")) return;
    var btn = document.createElement("button");
    btn.className = "ql-method-btn";
    btn.setAttribute("data-method", "pix");
    btn.style.cssText = "background:linear-gradient(135deg,rgba(16,185,129,0.15),rgba(5,150,105,0.08));border:1px solid rgba(16,185,129,0.35);color:#34d399";
    btn.innerHTML = "🇧🇷 PIX";
    btn.addEventListener("click", function(e){
      e.stopPropagation();
      renderForm("mensal");
    });
    parent.appendChild(btn);
  }

  // Also expose a "PIX" entry button on the packages list
  function tryInjectPixOnPackages(){
    var box = document.getElementById("ql-floating");
    if (!box) return;
    var list = box.querySelector("#ql-packages-list");
    if (!list) return;
    if (box.querySelector("#qlpix-cta")) return;
    var cta = document.createElement("button");
    cta.id = "qlpix-cta";
    cta.style.cssText = "margin:10px 14px;padding:11px;background:linear-gradient(135deg,#10b981,#059669);color:#fff;border:0;border-radius:10px;font-weight:700;cursor:pointer;font-size:13px;display:flex;align-items:center;justify-content:center;gap:8px;width:calc(100% - 28px)";
    cta.innerHTML = "🇧🇷 " + esc(t("PIX (Brasil)"));
    cta.addEventListener("click", function(){ renderForm("mensal"); });
    list.parentElement.insertBefore(cta, list);
  }

  var mo;
  function startObserver(){
    if (mo) return;
    try {
      mo = new MutationObserver(function(){
        tryInjectPixButton();
        tryInjectPixOnPackages();
      });
      mo.observe(document.documentElement, { childList: true, subtree: true });
    } catch(e){}
  }

  window.QL_PIX = { show: function(){ renderForm("mensal"); } };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", startObserver, { once: true });
  } else {
    startObserver();
  }
})();
