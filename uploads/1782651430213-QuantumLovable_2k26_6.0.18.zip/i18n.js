// Quantum Lovable — Extension i18n (PT/EN/ES/IT)
// Wraps a DOM walker that swaps Portuguese phrases for the active language.
// Strings live in a flat dictionary; missing keys fall back to PT (the original).
(function(){
  "use strict";
  if (window.__qlI18nLoaded) return;
  window.__qlI18nLoaded = true;

  var SUPPORTED = ["pt","en","es","it"];
  var LABELS = { pt: "🇧🇷 PT", en: "🇬🇧 EN", es: "🇪🇸 ES", it: "🇮🇹 IT" };
  var DICT = {
    en: {
      "Quantum Lovable": "Quantum Lovable",
      "Ativar Licença": "Activate License",
      "Insira sua chave de licença para desbloquear.": "Enter your license key to unlock.",
      "Validar Licença": "Validate License",
      "ou": "or",
      "🛒 Comprar Licença": "🛒 Buy License",
      "Notificações": "Notifications",
      "Abrir no Painel Lateral": "Open in Side Panel",
      "Tema": "Theme",
      "Sair": "Sign out",
      "Idioma": "Language",
      "⏳ Aguardando sincronização...": "⏳ Waiting for sync...",
      "💼 Painel do Revendedor": "💼 Reseller Panel",
      "⚡ Prompt": "⚡ Prompt",
      "💬 Histórico": "💬 History",
      "Carregando Modelo...": "Loading Model...",
      "Melhor para lógica e codificação": "Best for logic and coding",
      "Excelente raciocínio e contexto longo": "Excellent reasoning, long context",
      "Criatividade e escrita natural": "Creativity and natural writing",
      "Digite seu comando...": "Type your command...",
      "Modo Plano": "Plan Mode",
      "Anexar arquivo (máx. 10)": "Attach file (max 10)",
      "Otimizar com IA": "Optimize with AI",
      "Voz para texto": "Voice to text",
      "Enviar": "Send",
      "ATALHOS RÁPIDOS": "QUICK SHORTCUTS",
      "🚫 Remover Marca de Água": "🚫 Remove Watermark",
      "Ativar Escudo": "Enable Shield",
      "Desativar Escudo": "Disable Shield",
      "Usar Chat Padrão": "Use Default Chat",
      "📥 Baixar Todos Arquivos": "📥 Download All Files",
      "🚀 Criar Projeto no Lovable": "🚀 Create Project on Lovable",
      "🌐 Publicar Projeto": "🌐 Publish Project",
      "☁️ Ativar Cloud Do Lovable": "☁️ Enable Lovable Cloud",
      "Suporte": "Support",
      "🇲🇿 Desenvolvido em Moçambique": "🇲🇿 Made in Mozambique",
      "Licença Expirada!": "License Expired!",
      "O prazo da sua licença terminou. Renove agora para continuar.": "Your license has expired. Renew now to continue.",
      "🛒 Renovar Agora": "🛒 Renew Now",
      "Fechar": "Close",
      "Carregando...": "Loading...",
      "Nenhum plano disponível.": "No plans available.",
      "Erro ao carregar planos. Tente novamente.": "Failed to load plans. Please try again.",
      "Voltar": "Back",
      "Escolha o método de pagamento": "Choose payment method",
      "Pagar": "Pay",
      "Número deve ter 9 dígitos.": "Number must have 9 digits.",
      "M-Pesa: use 84 ou 85.": "M-Pesa: use 84 or 85.",
      "e-Mola: use 86 ou 87.": "e-Mola: use 86 or 87.",
      "⏳ Processando...": "⏳ Processing...",
      "Enviando solicitação de pagamento...": "Sending payment request...",
      "Pagamento falhou. Tente novamente.": "Payment failed. Try again.",
      "Erro de conexão.": "Connection error.",
      "Sucesso!": "Success!",
      "📋 Copiar Chave": "📋 Copy Key",
      "✅ Copiado!": "✅ Copied!",
      "🔑 Ativar Agora": "🔑 Activate Now",
      "PIX (Brasil)": "PIX (Brazil)",
      "Nome completo": "Full name",
      "Nome e sobrenome (ex: João Silva)": "First and last name (e.g. John Doe)",
      "CPF (apenas números)": "CPF (numbers only)",
      "Telefone com DDD": "Phone with area code",
      "Gerar PIX": "Generate PIX",
      "Aguardando pagamento...": "Waiting for payment...",
      "Pagamento confirmado!": "Payment confirmed!",
      "Copiar código PIX": "Copy PIX code",
      "Código copiado!": "Code copied!",
      "Sua chave de licença": "Your license key",
      "Acesso Negado": "Access Denied",
      "Aguardando licença...": "Waiting for license...",
    },
    es: {
      "Ativar Licença": "Activar Licencia",
      "Insira sua chave de licença para desbloquear.": "Ingresa tu clave de licencia para desbloquear.",
      "Validar Licença": "Validar Licencia",
      "ou": "o",
      "🛒 Comprar Licença": "🛒 Comprar Licencia",
      "Notificações": "Notificaciones",
      "Abrir no Painel Lateral": "Abrir en Panel Lateral",
      "Tema": "Tema",
      "Sair": "Salir",
      "Idioma": "Idioma",
      "⏳ Aguardando sincronização...": "⏳ Esperando sincronización...",
      "💼 Painel do Revendedor": "💼 Panel del Revendedor",
      "⚡ Prompt": "⚡ Prompt",
      "💬 Histórico": "💬 Historial",
      "Carregando Modelo...": "Cargando Modelo...",
      "Melhor para lógica e codificação": "Mejor para lógica y codificación",
      "Excelente raciocínio e contexto longo": "Excelente razonamiento y contexto largo",
      "Criatividade e escrita natural": "Creatividad y escritura natural",
      "Digite seu comando...": "Escribe tu comando...",
      "Modo Plano": "Modo Plan",
      "Anexar arquivo (máx. 10)": "Adjuntar archivo (máx. 10)",
      "Otimizar com IA": "Optimizar con IA",
      "Voz para texto": "Voz a texto",
      "Enviar": "Enviar",
      "ATALHOS RÁPIDOS": "ATAJOS RÁPIDOS",
      "🚫 Remover Marca de Água": "🚫 Quitar Marca de Agua",
      "Ativar Escudo": "Activar Escudo",
      "Desativar Escudo": "Desactivar Escudo",
      "Usar Chat Padrão": "Usar Chat Estándar",
      "📥 Baixar Todos Arquivos": "📥 Descargar Todos los Archivos",
      "🚀 Criar Projeto no Lovable": "🚀 Crear Proyecto en Lovable",
      "🌐 Publicar Projeto": "🌐 Publicar Proyecto",
      "☁️ Ativar Cloud Do Lovable": "☁️ Activar Cloud de Lovable",
      "Suporte": "Soporte",
      "🇲🇿 Desenvolvido em Moçambique": "🇲🇿 Hecho en Mozambique",
      "Licença Expirada!": "¡Licencia Expirada!",
      "O prazo da sua licença terminou. Renove agora para continuar.": "Tu licencia ha expirado. Renueva ahora para continuar.",
      "🛒 Renovar Agora": "🛒 Renovar Ahora",
      "Fechar": "Cerrar",
      "Carregando...": "Cargando...",
      "Nenhum plano disponível.": "No hay planes disponibles.",
      "Erro ao carregar planos. Tente novamente.": "Error al cargar planes. Intenta de nuevo.",
      "Voltar": "Volver",
      "Escolha o método de pagamento": "Elige el método de pago",
      "Pagar": "Pagar",
      "⏳ Processando...": "⏳ Procesando...",
      "Enviando solicitação de pagamento...": "Enviando solicitud de pago...",
      "Pagamento falhou. Tente novamente.": "Pago fallido. Intenta de nuevo.",
      "Erro de conexão.": "Error de conexión.",
      "Sucesso!": "¡Éxito!",
      "📋 Copiar Chave": "📋 Copiar Clave",
      "✅ Copiado!": "✅ ¡Copiado!",
      "🔑 Ativar Agora": "🔑 Activar Ahora",
      "PIX (Brasil)": "PIX (Brasil)",
      "Nome completo": "Nombre completo",
      "Nome e sobrenome (ex: João Silva)": "Nombre y apellido (ej: Juan Pérez)",
      "CPF (apenas números)": "CPF (solo números)",
      "Telefone com DDD": "Teléfono con código de área",
      "Gerar PIX": "Generar PIX",
      "Aguardando pagamento...": "Esperando pago...",
      "Pagamento confirmado!": "¡Pago confirmado!",
      "Copiar código PIX": "Copiar código PIX",
      "Código copiado!": "¡Código copiado!",
      "Sua chave de licença": "Tu clave de licencia",
      "Acesso Negado": "Acceso Denegado",
      "Aguardando licença...": "Esperando licencia...",
    },
    it: {
      "Ativar Licença": "Attiva Licenza",
      "Insira sua chave de licença para desbloquear.": "Inserisci la tua chiave di licenza per sbloccare.",
      "Validar Licença": "Convalida Licenza",
      "ou": "o",
      "🛒 Comprar Licença": "🛒 Acquista Licenza",
      "Notificações": "Notifiche",
      "Abrir no Painel Lateral": "Apri nel Pannello Laterale",
      "Tema": "Tema",
      "Sair": "Esci",
      "Idioma": "Lingua",
      "⏳ Aguardando sincronização...": "⏳ In attesa di sincronizzazione...",
      "💼 Painel do Revendedor": "💼 Pannello del Rivenditore",
      "⚡ Prompt": "⚡ Prompt",
      "💬 Histórico": "💬 Cronologia",
      "Carregando Modelo...": "Caricamento Modello...",
      "Melhor para lógica e codificação": "Migliore per logica e codifica",
      "Excelente raciocínio e contexto longo": "Ottimo ragionamento e contesto lungo",
      "Criatividade e escrita natural": "Creatività e scrittura naturale",
      "Digite seu comando...": "Digita il tuo comando...",
      "Modo Plano": "Modalità Piano",
      "Anexar arquivo (máx. 10)": "Allega file (max 10)",
      "Otimizar com IA": "Ottimizza con AI",
      "Voz para texto": "Voce a testo",
      "Enviar": "Invia",
      "ATALHOS RÁPIDOS": "SCORCIATOIE RAPIDE",
      "🚫 Remover Marca de Água": "🚫 Rimuovi Filigrana",
      "Ativar Escudo": "Attiva Scudo",
      "Desativar Escudo": "Disattiva Scudo",
      "Usar Chat Padrão": "Usa Chat Predefinita",
      "📥 Baixar Todos Arquivos": "📥 Scarica Tutti i File",
      "🚀 Criar Projeto no Lovable": "🚀 Crea Progetto su Lovable",
      "🌐 Publicar Projeto": "🌐 Pubblica Progetto",
      "☁️ Ativar Cloud Do Lovable": "☁️ Attiva Lovable Cloud",
      "Suporte": "Supporto",
      "🇲🇿 Desenvolvido em Moçambique": "🇲🇿 Sviluppato in Mozambico",
      "Licença Expirada!": "Licenza Scaduta!",
      "O prazo da sua licença terminou. Renove agora para continuar.": "La tua licenza è scaduta. Rinnova ora per continuare.",
      "🛒 Renovar Agora": "🛒 Rinnova Ora",
      "Fechar": "Chiudi",
      "Carregando...": "Caricamento...",
      "Nenhum plano disponível.": "Nessun piano disponibile.",
      "Erro ao carregar planos. Tente novamente.": "Errore nel caricare i piani. Riprova.",
      "Voltar": "Indietro",
      "Escolha o método de pagamento": "Scegli il metodo di pagamento",
      "Pagar": "Paga",
      "⏳ Processando...": "⏳ Elaborazione...",
      "Enviando solicitação de pagamento...": "Invio richiesta di pagamento...",
      "Pagamento falhou. Tente novamente.": "Pagamento fallito. Riprova.",
      "Erro de conexão.": "Errore di connessione.",
      "Sucesso!": "Successo!",
      "📋 Copiar Chave": "📋 Copia Chiave",
      "✅ Copiado!": "✅ Copiato!",
      "🔑 Ativar Agora": "🔑 Attiva Ora",
      "PIX (Brasil)": "PIX (Brasile)",
      "Nome completo": "Nome completo",
      "Nome e sobrenome (ex: João Silva)": "Nome e cognome (es: Mario Rossi)",
      "CPF (apenas números)": "CPF (solo numeri)",
      "Telefone com DDD": "Telefono con prefisso",
      "Gerar PIX": "Genera PIX",
      "Aguardando pagamento...": "In attesa di pagamento...",
      "Pagamento confirmado!": "Pagamento confermato!",
      "Copiar código PIX": "Copia codice PIX",
      "Código copiado!": "Codice copiato!",
      "Sua chave de licença": "La tua chiave di licenza",
      "Acesso Negado": "Accesso Negato",
      "Aguardando licença...": "In attesa della licenza...",
    },
    pt: {} // identity
  };

  var ATTRS = ["placeholder","title","aria-label","alt"];
  var ORIG = new WeakMap();
  var ORIG_ATTR = new WeakMap();
  var currentLang = "pt";
  var observer = null;

  function t(s){
    if (currentLang === "pt") return s;
    var d = DICT[currentLang] || {};
    return d[s] || s;
  }

  function translateTextNode(node){
    var orig = ORIG.get(node);
    if (orig == null) {
      orig = node.nodeValue || "";
      ORIG.set(node, orig);
    }
    var trimmed = orig.trim();
    if (!trimmed) return;
    var translated = t(trimmed);
    if (translated === trimmed && currentLang !== "pt") return; // no entry
    if (currentLang === "pt") {
      if (node.nodeValue !== orig) node.nodeValue = orig;
      return;
    }
    var newVal = orig.replace(trimmed, translated);
    if (node.nodeValue !== newVal) node.nodeValue = newVal;
  }

  function translateAttr(el){
    var map = ORIG_ATTR.get(el);
    if (!map) { map = {}; ORIG_ATTR.set(el, map); }
    for (var i = 0; i < ATTRS.length; i++){
      var a = ATTRS[i];
      if (!el.hasAttribute(a)) continue;
      if (map[a] == null) map[a] = el.getAttribute(a);
      var orig = map[a] || "";
      var trimmed = orig.trim();
      if (!trimmed) continue;
      var translated = currentLang === "pt" ? orig : t(trimmed);
      var newVal = currentLang === "pt" ? orig : orig.replace(trimmed, translated);
      if (el.getAttribute(a) !== newVal) el.setAttribute(a, newVal);
    }
  }

  function walk(root){
    if (!root) return;
    // text nodes
    var tw = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, null);
    var n;
    while ((n = tw.nextNode())) {
      var p = n.parentElement;
      if (!p) continue;
      var tag = (p.tagName || "").toLowerCase();
      if (tag === "script" || tag === "style" || tag === "textarea" || tag === "input") continue;
      translateTextNode(n);
    }
    // attributes
    var els = root.querySelectorAll ? root.querySelectorAll("*") : [];
    for (var i = 0; i < els.length; i++) translateAttr(els[i]);
  }

  function applyAll(){
    var roots = [
      document.getElementById("ql-floating"),
      document.querySelector(".sp-app") || document.querySelector(".sp-root") || document.body,
    ];
    for (var i = 0; i < roots.length; i++) walk(roots[i]);
  }

  var scheduled = false;
  function schedule(){
    if (scheduled) return;
    scheduled = true;
    setTimeout(function(){ scheduled = false; applyAll(); }, 60);
  }

  function startObserver(){
    if (observer) return;
    try {
      observer = new MutationObserver(function(){ schedule(); });
      observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true });
    } catch(e){}
  }

  function setLang(lang){
    if (SUPPORTED.indexOf(lang) < 0) return;
    currentLang = lang;
    try { chrome.storage.local.set({ ql_lang: lang }); } catch(e){}
    applyAll();
  }

  function loadInitial(cb){
    try {
      chrome.storage.local.get(["ql_lang"], function(res){
        if (res && SUPPORTED.indexOf(res.ql_lang) >= 0) {
          currentLang = res.ql_lang;
          if (cb) cb();
          return;
        }
        // fallback to backend default
        fetchDefaultLang().then(function(lang){
          currentLang = lang || "pt";
          if (cb) cb();
        }).catch(function(){
          currentLang = "pt";
          if (cb) cb();
        });
      });
    } catch(e){ currentLang = "pt"; if (cb) cb(); }
  }

  function fetchDefaultLang(){
    var SUPABASE_URL = "https://itsgcyiyemstpfafxrpq.supabase.co";
    var ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml0c2djeWl5ZW1zdHBmYWZ4cnBxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEwMTgxMjEsImV4cCI6MjA5NjU5NDEyMX0.-MIslf_PAA9VCmKNCGJ_9QTXze4ej7OQEZ1UYKC3UgE";
    return fetch(SUPABASE_URL + "/rest/v1/app_settings?key=eq.ext_default_language&select=value", {
      headers: { apikey: ANON, Authorization: "Bearer " + ANON }
    }).then(function(r){ return r.json(); }).then(function(rows){
      if (Array.isArray(rows) && rows[0] && rows[0].value) return String(rows[0].value);
      return "pt";
    });
  }

  function buildDropdown(){
    var wrap = document.createElement("div");
    wrap.className = "ql-lang-wrap";
    wrap.style.cssText = "position:relative;display:inline-block";
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "ql-icon-btn ql-lang-btn";
    btn.title = t("Idioma");
    btn.textContent = (LABELS[currentLang] || LABELS.pt).split(" ")[0];
    btn.style.cssText = "font-size:14px;line-height:1;padding:4px 6px";
    var menu = document.createElement("div");
    menu.className = "ql-lang-menu";
    menu.style.cssText = "position:absolute;top:calc(100% + 6px);right:0;background:var(--ql-bg,#0b1020);border:1px solid var(--ql-border,rgba(255,255,255,0.08));border-radius:10px;padding:4px;min-width:120px;box-shadow:0 8px 24px rgba(0,0,0,0.4);z-index:99999;display:none";
    SUPPORTED.forEach(function(lang){
      var item = document.createElement("button");
      item.type = "button";
      item.style.cssText = "display:block;width:100%;text-align:left;padding:8px 10px;background:transparent;border:0;color:var(--ql-text,#fff);font-size:12px;border-radius:6px;cursor:pointer";
      item.textContent = LABELS[lang];
      item.addEventListener("mouseenter", function(){ item.style.background = "rgba(255,255,255,0.06)"; });
      item.addEventListener("mouseleave", function(){ item.style.background = "transparent"; });
      item.addEventListener("click", function(e){
        e.stopPropagation();
        setLang(lang);
        btn.textContent = LABELS[lang].split(" ")[0];
        menu.style.display = "none";
      });
      menu.appendChild(item);
    });
    btn.addEventListener("click", function(e){
      e.stopPropagation();
      menu.style.display = menu.style.display === "none" ? "block" : "none";
    });
    document.addEventListener("click", function(){ menu.style.display = "none"; });
    wrap.appendChild(btn);
    wrap.appendChild(menu);
    return wrap;
  }

  function injectInto(headerRight){
    if (!headerRight || headerRight.querySelector(".ql-lang-wrap")) return;
    headerRight.insertBefore(buildDropdown(), headerRight.firstChild);
  }

  function injectAll(){
    var floats = document.querySelectorAll("#ql-floating .ql-header-right");
    floats.forEach(injectInto);
    var sp = document.querySelectorAll(".sp-header-actions, .sp-header-right");
    sp.forEach(injectInto);
  }

  // Expose
  window.QL_I18N = {
    t: t,
    setLang: setLang,
    getLang: function(){ return currentLang; },
    apply: applyAll,
    inject: injectAll,
    SUPPORTED: SUPPORTED,
    LABELS: LABELS,
  };

  function start(){
    loadInitial(function(){
      applyAll();
      injectAll();
      startObserver();
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else {
    start();
  }
})();
